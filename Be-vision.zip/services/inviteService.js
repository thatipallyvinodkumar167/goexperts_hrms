import prisma from "../config/db.js";
import crypto from "crypto";
import { sendEmail } from "../utils/sendEmail.js";
import { hashPassword } from "../utils/hashPassword.js";
import { generateOfferLetter } from "../utils/pdfGenerator.js";

export const inviteService = async (data) => {
  const {
    email,
    role,
    companyId,
    isNewHire,
    offerData,
    createdById,
    name,
    password,
    departmentId,
    designationId,
    workModel,         // "WFO" | "WFH" | "HYBRID"
    expectedOfficeDays // For HYBRID: number of days/week (e.g., 3)
  } = data;

  const normalizedEmail = email.trim().toLowerCase();

  const existingUser = await prisma.user.findFirst({
    where: {
      email: normalizedEmail,
      role: { in: ["EMPLOYEE", "HR"] }
    }
  });

  if (existingUser) {
    throw new Error("This email is already used by an employee or HR account");
  }

  const rawToken = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
  let invite;

  ////////////////////////
  // 🔥 1. NEW HIRE FLOW (Offer Letter for HR or EMPLOYEE)
  ////////////////////////
  if (isNewHire) {
      if (!offerData) throw new Error("Offer data required");

      await prisma.offerLetter.create({
          data: {
              name: name || normalizedEmail.split('@')[0],
              employeeEmail: normalizedEmail,
              companyId,
              ctc: offerData.salary,
              joiningDate: new Date(offerData.joiningDate),
              position: offerData.position,
              role: role,
              departmentId,
              designationId,
              status: "SENT",
              // Store work model in offer data for reference
              workModel: workModel || "WFO",
              expectedOfficeDays: expectedOfficeDays ? parseInt(expectedOfficeDays) : null,
          }
      });

      const company = await prisma.company.findUnique({ where: { id: companyId } });

      // Generate the Offer Letter PDF in the background
      generateOfferLetter({
          email: normalizedEmail,
          position: offerData.position,
          salary: offerData.salary,
          joiningDate: offerData.joiningDate,
          company: {
              name: company?.name || "Our Company",
              address: company?.location || "India",
              logo: company?.companyLogo || null
          }
      }).then(({ filePath, fileName }) => {
          sendEmail(
            normalizedEmail,
            "Offer Letter - GOExperts HRMS",
            `<h2>Congratulations!</h2>
             <p>We are pleased to offer you the position of <strong>${offerData.position}</strong>.</p>
             <p>Please find your formal offer letter attached to this email.</p>
             <br/>
             <p>Click below to accept your offer directly:</p>
             <a href="${process.env.BACKEND_URL || 'https://goexperts-hrms-coun.onrender.com'}/api/invite/accept-offer?email=${normalizedEmail}" 
                style="background: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin-top: 10px;">
                Accept Offer
             </a>`,
            [{ filename: fileName, path: filePath }]
          ).catch(err => console.error("Offer Email Failed:", err.message));
      }).catch(err => console.error("PDF Generation Failed:", err.message));

      return { message: "Offer and PDF sent successfully" };
  }

  ////////////////////////
  // 🔥 2. MIGRATION FLOW (Existing HR with Password)
  ////////////////////////
  if (!isNewHire && role === "HR" && password) {
      const hashedPassword = await hashPassword(password);
      
      const result = await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            name: name || "HR Admin",
            email: normalizedEmail,
            password: hashedPassword,
            role: "HR",
            companyId,
            status: "ACTIVE",
            isEmailVerified: true
          }
        });

        const employee = await tx.employee.create({
          data: {
            userId: user.id,
            companyId,
            employeeCode: `HR-${Date.now()}`,
            departmentId,
            designationId,
            joiningDate: new Date(),
            employmentType: "EXPERIENCED",
            workModel: workModel || "WFO",
            expectedOfficeDays: (workModel === "HYBRID" && expectedOfficeDays) ? parseInt(expectedOfficeDays) : null,
          }
        });

        await tx.hR.create({
          data: {
            userId: user.id,
            permissions: {
              canManageEmployees: true,
              canManageAttendance: true,
              canManageLeaves: true,
              canManagePayroll: true
            }
          }
        });

        return { user, employee };
      });

      sendEmail(
        normalizedEmail,
        "Welcome to HRMS",
        `<h3>Welcome aboard!</h3>
         <p>Your HR account has been created.</p>
         <p>Email: ${normalizedEmail}</p>
         <p>You can login now at: ${process.env.FRONTEND_URL}/login</p>`
      ).catch(err => console.error("Migration Email Failed:", err.message));

      return { message: "Account activated successfully and Welcome Letter sent" };
  }

  ////////////////////////
  // 🔥 3. STANDARD INVITE FLOW (Existing Employee/HR without Offer)
  ////////////////////////
  invite = await prisma.employeeInvite.create({
      data: {
          email: normalizedEmail,
          name: name || normalizedEmail.split('@')[0],
          token: rawToken,
          role: role,
          companyId,
          departmentId,
          designationId,
          expiresAt,
          // Store work model in invite for use during profile completion
          workModel: workModel || "WFO",
          expectedOfficeDays: (workModel === "HYBRID" && expectedOfficeDays) ? parseInt(expectedOfficeDays) : null,
      }
  });

  sendEmail(
      normalizedEmail,
      `${role === "HR" ? "HR" : "Employee"} Invitation`,
      `<h3>You are invited to join as ${role === "HR" ? "HR" : "an Employee"}</h3>
       <a href="${process.env.FRONTEND_URL}/setup-password?token=${rawToken}">
       Setup Account</a>`
  ).catch(err => console.error("Invite Email Failed:", err.message));

  ////////////////////////
  // AUDIT LOG
  ////////////////////////
  await prisma.auditLog.create({
    data: {
      userId: createdById,
      action: "INVITE_SENT",
      module: role
    }
  });

  return {
    message: `${role} invite sent`,
    inviteToken: rawToken
  };
};

export const acceptInviteService = async ({ token, password, name }) => {
  const invite = await prisma.employeeInvite.findFirst({
    where: {
      token,
      expiresAt: { gt: new Date() },
      acceptedAt: null
    }
  });

  if (!invite) {
    throw new Error("Invalid or expired invite");
  }

  const existingUser = await prisma.user.findFirst({
    where: {
      email: invite.email,
      role: { in: ["EMPLOYEE", "HR"] }
    }
  });

  if (existingUser) {
    throw new Error("This email is already used by an employee or HR account");
  }

  const hashedPassword = await hashPassword(password);

  const result = await prisma.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: {
        name,
        email: invite.email,
        password: hashedPassword,
        role: invite.role,
        companyId: invite.companyId,
        status: "PENDING_APPROVAL",
        isEmailVerified: false
      }
    });

    // ✅ Create Employee record for both EMPLOYEE and HR roles
    // This ensures HR can apply leaves, mark attendance, and receive payroll
    if (invite.departmentId && invite.designationId) {
      const prefix = invite.role === "HR" ? "HR" : "EMP";
      const employee = await tx.employee.create({
        data: {
          userId: user.id,
          companyId: invite.companyId,
          employeeCode: `${prefix}-${Date.now()}`,
          departmentId: invite.departmentId,
          designationId: invite.designationId,
          joiningDate: new Date(),
          employmentType: "EXPERIENCED",
          workModel: invite.workModel || "WFO",
          expectedOfficeDays: (invite.workModel === "HYBRID" && invite.expectedOfficeDays)
            ? invite.expectedOfficeDays
            : null,
        }
      });

      // If HR, also create the HR record for permissions
      if (invite.role === "HR") {
        await tx.hR.create({
          data: {
            userId: user.id,
            permissions: {
              canManageEmployees: true,
              canManageAttendance: true,
              canManageLeaves: true,
              canManagePayroll: true
            }
          }
        });
      }
    }

    await tx.employeeInvite.update({
      where: { id: invite.id },
      data: { acceptedAt: new Date() }
    });

    return user;
  });

  return {
    message: "Password set. Verify email next",
    userId: result.id
  };
};

export const verifyEmailService = async (userId) => {
  const user = await prisma.user.findUnique({
    where: { id: userId }
  });

  if (!user) throw new Error("User not found");

  await prisma.user.update({
    where: { id: userId },
    data: { isEmailVerified: true }
  });

  return { message: "Email verified" };
};

export const completeProfileService = async ({
  userId,
  personal,
  departmentId,
  designationId
}) => {
  const user = await prisma.user.findUnique({
    where: { id: userId }
  });
  if (!user) throw new Error("User not found");

  // Read workModel from the accepted EmployeeInvite record
  const invite = await prisma.employeeInvite.findFirst({
    where: {
      email: user.email,
      companyId: user.companyId,
      acceptedAt: { not: null }
    },
    orderBy: { createdAt: "desc" }
  });

  const workModel = invite?.workModel || "WFO";
  const expectedOfficeDays = invite?.expectedOfficeDays || null;

  // Check if employee already exists (e.g. HR who was already given an employee record)
  const existingEmployee = await prisma.employee.findUnique({ where: { userId } });

  let employee;
  if (existingEmployee) {
    // Just update personal details if employee record already exists
    employee = await prisma.employee.update({
      where: { userId },
      data: {
        departmentId: departmentId || existingEmployee.departmentId,
        designationId: designationId || existingEmployee.designationId,
        personal: personal ? { upsert: { create: personal, update: personal } } : undefined
      }
    });
  } else {
    const prefix = user.role === "HR" ? "HR" : "EMP";
    employee = await prisma.employee.create({
      data: {
        userId,
        companyId: user.companyId,
        employeeCode: `${prefix}-${Date.now()}`,
        departmentId,
        designationId,
        joiningDate: new Date(),
        employmentType: "FRESHER",
        workModel,
        expectedOfficeDays,
        personal: {
          create: personal
        }
      }
    });
  }

  return { message: "Profile completed", employee };
};

export const activateUserService = async (userId) => {
  const user = await prisma.user.findUnique({
    where: { id: userId }
  });

  if (!user) throw new Error("User not found");

  if (!user.isEmailVerified) {
    throw new Error("Verify email first");
  }

  await prisma.user.update({
    where: { id: userId },
    data: { status: "ACTIVE" }
  });

  return { message: "User activated" };
};

// --- NEW: THE BRIDGE BETWEEN OFFER AND INVITE ---
export const acceptOfferService = async (email) => {
    const normalizedEmail = email.trim().toLowerCase();

    // 1. Find the latest offer for this email
    const offer = await prisma.offerLetter.findFirst({
        where: { employeeEmail: normalizedEmail },
        orderBy: { createdAt: "desc" }
    });

    if (!offer) {
        throw new Error("No offer found for this email");
    }

    if (offer.status === "ACCEPTED") {
        throw new Error("Offer already accepted. Please check your email for the password setup link.");
    }

    if (offer.status !== "SENT") {
        throw new Error(`Offer cannot be accepted. Current status: ${offer.status}`);
    }

    // 2. Mark as ACCEPTED
    await prisma.offerLetter.update({
        where: { id: offer.id },
        data: { status: "ACCEPTED" }
    });

    // 3. Automatically trigger the Invitation (Phase 2)
    // ✅ Carry over workModel & expectedOfficeDays from the OfferLetter
    const rawToken = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);

    await prisma.employeeInvite.create({
        data: {
            email: normalizedEmail,
            name: offer.name,
            token: rawToken,
            role: offer.role,
            companyId: offer.companyId,
            departmentId: offer.departmentId,
            designationId: offer.designationId,
            workModel: offer.workModel || "WFO",
            expectedOfficeDays: offer.expectedOfficeDays || null,
            expiresAt
        }
    });

    // 4. Send the "Setup Account" email (Only after acceptance)
    sendEmail(
        normalizedEmail,
        "Welcome! Setup your HRMS Account",
        `<h3>Offer Accepted!</h3>
         <p>Thank you for accepting the offer to join us as <strong>${offer.position}</strong>.</p>
         <p>We are excited to have you join the team.</p>
         <p>The final step is to set up your password to begin your digital onboarding.</p>
         <br/>
         <a href="${process.env.FRONTEND_URL}/setup-password?token=${rawToken}" 
            style="background: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
            Set Password & Join
         </a>`
    ).catch(err => console.error("Setup Account Email Failed:", err.message));

    return { message: "Offer accepted successfully. Setup email sent." };
};
