import prisma from "../config/db.js";
import { hashPassword } from "../utils/hashPassword.js";
import { sendEmail } from "../utils/sendEmail.js";
import { generateJoiningLetter } from "../utils/pdfGenerator.js";


// ✅ STEP 1 + 2: Accept Invite + Set Password
export const acceptInviteService = async ({token, password, name}) => {
    
    const invite  = await prisma.employeeInvite.findFirst({
        where : {
            token,
        }
    });

    if(!invite){
        throw Error("Invalid token");
    }

    if(invite.expiresAt < new Date()){
        throw Error("Token has expired");
    }

    if(invite.acceptedAt){
        throw Error("The password has already been set for this account");
    }

    const hashedPassword  = await hashPassword(password);

    // ✅ FIX: Use a transaction to prevent partial creation, and handle orphaned records
    await prisma.$transaction(async (tx) => {
        
        // 1. Check if user already exists from a previous failed attempt
        let user = await tx.user.findFirst({
            where: { email: invite.email }
        });

        if (user) {
            if (user.companyId !== invite.companyId || ["EMPLOYEE", "HR"].includes(user.role)) {
                throw Error("This email is already used by an employee or HR account");
            }

            user = await tx.user.update({
                where: { id: user.id },
                data: { password: hashedPassword, name: name || user.name }
            });
        } else {
            user = await tx.user.create({
              data : {
                    name: name || invite.email.split('@')[0],
                    email : invite.email,
                    password : hashedPassword,
                    role : invite.role,
                    companyId : invite.companyId,
                    status : "PENDING_APPROVAL",
                    isEmailVerified : true
                }
            });
        }

        // Check if the provided department and designation actually exist in this company
        const validDept = await tx.department.findUnique({ where: { id: invite.departmentId || "" } });
        const validDesig = await tx.designation.findUnique({ where: { id: invite.designationId || "" } });

        // Fallbacks just in case the HR used the wrong ID during invite
        let finalDeptId = invite.departmentId;
        let finalDesigId = invite.designationId;

        if (!validDept) {
            const firstDept = await tx.department.findFirst({ where: { companyId: invite.companyId } });
            if (!firstDept) throw new Error("Company has no departments setup yet.");
            finalDeptId = firstDept.id;
        }

        if (!validDesig) {
            const firstDesig = await tx.designation.findFirst({ where: { companyId: invite.companyId } });
            if (!firstDesig) throw new Error("Company has no designations setup yet.");
            finalDesigId = firstDesig.id;
        }

        // 2. Check if employee record already exists
        const existingEmployee = await tx.employee.findFirst({
            where: { userId: user.id }
        });

        if (!existingEmployee) {
            await tx.employee.create({
              data: {
                  userId: user.id,
                  companyId: invite.companyId,
                  employeeCode: `EMP-${Date.now()}`,
                  departmentId: finalDeptId,
                  designationId: finalDesigId,
                  joiningDate: new Date(),
                  employmentType: "FRESHER",
                  status: "INVITED",
                  // ✅ Dynamically carry over workModel from the invite set by HR
                  workModel: invite.workModel || "WFO",
                  expectedOfficeDays: invite.expectedOfficeDays || null,
              }
            });
        }

        // 3. Mark invite accepted
        await tx.employeeInvite.update({
            where: { id: invite.id },
            data: { acceptedAt: new Date() }
        });
    }, { timeout: 20000 }); // Increase timeout to 20 seconds for slow free tier DB

    // We must return the user ID for the next steps, so fetch it outside transaction
    const finalUser = await prisma.user.findFirst({
        where: { email: invite.email }
    });

    return {
        message: "Password set. Verify email next",
        userId: finalUser.id
    };
};


// step 2 verify email
export const verifyEmailService  = async (userId) => {

    const user = await prisma.user.findFirst({
        where : {id : userId}
    });

    if(!user){
        throw Error("user not found")
    }

    await prisma.user.update({
        where : {id : user.id},
        isEmailVerified : true
    });
    return { message : "email verified successfully"}
};

// ✅ STEP 1: Basic Information
export const saveBasicInfoService = async (userId, data) => {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw Error("User not found");

    let employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee record missing. Please contact HR.");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");
    
    // Update the existing employee record
    // Update both the existing employee record and the user record for visual consistency
    await prisma.$transaction([
        prisma.employee.update({
            where: { id: employee.id },
            data: {
                firstName: data.firstName,
                lastName: data.lastName,
                middleName: data.middleName,
                profilePhoto: data.profilePhoto,
                faceVerificationPhoto: data.profilePhoto
            }
        }),
        prisma.user.update({
            where: { id: userId },
            data: { profileLogo: data.profilePhoto }
        })
    ]);
    
    await prisma.employeePersonal.upsert({
        where: { employeeId: employee.id },
        update: {
            gender: data.gender,
            dob: data.dob ? new Date(data.dob) : null,
            maritalStatus: data.maritalStatus,
            bloodGroup: data.bloodGroup,
            nationality: data.nationality
        },
        create: {
            employeeId: employee.id,
            gender: data.gender,
            dob: data.dob ? new Date(data.dob) : null,
            maritalStatus: data.maritalStatus,
            bloodGroup: data.bloodGroup,
            nationality: data.nationality
        }
    });

    return { message: "Basic information saved", employee };
};

// ✅ STEP 2: Contact Information
export const saveContactInfoService = async (userId, data) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    await prisma.employeePersonal.upsert({
        where: { employeeId: employee.id },
        update: {
            personalEmail: data.personalEmail,
            phone: data.phone,
            alternatePhone: data.alternatePhone,
            address: data.address,
            city: data.city,
            state: data.state,
            country: data.country,
            pincode: data.pincode
        },
        create: {
            employeeId: employee.id,
            personalEmail: data.personalEmail,
            phone: data.phone,
            alternatePhone: data.alternatePhone,
            address: data.address,
            city: data.city,
            state: data.state,
            country: data.country,
            pincode: data.pincode
        }
    });



    return { message: "Contact information saved" };
};

// ✅ STEP 3: Emergency Contact
export const saveEmergencyContactService = async (userId, dataArray) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    // Clear existing to avoid duplicates on re-submission
    await prisma.employeeEmergencyContact.deleteMany({ where: { employeeId: employee.id } });

    await prisma.employeeEmergencyContact.createMany({
        data: dataArray.map(data => ({
            employeeId: employee.id,
            contactPersonName: data.contactPersonName,
            relationship: data.relationship,
            contactNumber: data.contactNumber
        }))
    });



    return { message: "Emergency contacts saved" };
};

// ✅ STEP 4: Education Details
export const saveEducationService = async (userId, dataArray) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    await prisma.employeeEducation.deleteMany({ where: { employeeId: employee.id } });

    await prisma.employeeEducation.createMany({
        data: dataArray.map(data => ({
            employeeId: employee.id,
            degree: data.degree,
            specialization: data.specialization,
            college: data.college,
            university: data.university,
            percentage: data.percentage,
            startYear: data.startYear,
            endYear: data.endYear
        }))
    });



    return { message: "Education details saved" };
};

// ✅ STEP 5: Experience Details
export const addExperienceService = async (userId, experienceArray) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw new Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    await prisma.employeeExperience.deleteMany({ where: { employeeId: employee.id } });

    const experiences = await prisma.employeeExperience.createMany({
        data: experienceArray.map(exp => ({
            employeeId: employee.id,
            companyName: exp.companyName,
            role: exp.designation || exp.role,
            startDate: new Date(exp.startDate),
            endDate: exp.endDate ? new Date(exp.endDate) : null,
            technologies: exp.technologies,
            responsibilities: exp.responsibilities
        }))
    });

    await prisma.employee.update({
        where: { id: employee.id },
        data: { 
            employmentType: experienceArray.length > 0 ? "EXPERIENCED" : employee.employmentType
        }
    });

    return { message: "Experience details saved", experiences };
};

// ✅ STEP 6: Skills & Certifications
export const saveSkillsService = async (userId, data) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    await prisma.employeeSkill.upsert({
        where: { employeeId: employee.id },
        update: {
            primarySkills: data.primarySkills,
            secondarySkills: data.secondarySkills,
            certifications: data.certifications,
            languagesKnown: data.languagesKnown,
            linkedinUrl: data.linkedinUrl,
            githubUrl: data.githubUrl,
            portfolioUrl: data.portfolioUrl
        },
        create: {
            employeeId: employee.id,
            primarySkills: data.primarySkills,
            secondarySkills: data.secondarySkills,
            certifications: data.certifications,
            languagesKnown: data.languagesKnown,
            linkedinUrl: data.linkedinUrl,
            githubUrl: data.githubUrl,
            portfolioUrl: data.portfolioUrl
        }
    });



    return { message: "Skills saved" };
};

// ✅ STEP 5: Activate Employee (Legacy Single Action)
export const activateUserService  = async (userId) => {
    const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
            employee: {
                include: {
                    designation: true
                }
            }
        }
    });

    if (!user) throw Error("User not found");
    if (!user.isEmailVerified) throw Error("Verify email first");

    await prisma.user.update({
        where: { id: userId },
        data: { status: "ACTIVE" }
    });

    // Generate Appointment/Joining Letter in background
    if (user.employee) {
        generateJoiningLetter({
            email: user.email,
            name: user.name,
            position: user.employee.designation?.title || "Team Member",
            joiningDate: user.employee.joiningDate.toLocaleDateString()
        }).then(({ filePath, fileName }) => {
            sendEmail(
                user.email,
                "Welcome Aboard! Appointment Letter - GOExperts HRMS",
                `<h3>Welcome to the Team, ${user.name}!</h3>
                 <p>Congratulations! Your account has been activated.</p>
                 <p>Please find your formal <strong>Appointment Letter</strong> attached to this email.</p>
                 <p>You can now log in to the dashboard using your credentials.</p>
                 <br/>
                 <a href="${process.env.FRONTEND_URL}/login" 
                    style="background: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
                    Login to Dashboard
                 </a>`,
                [{ filename: fileName, path: filePath }]
            ).catch(err => console.error("Welcome Email Failed:", err.message));
        }).catch(err => console.error("Joining PDF Generation Failed:", err.message));
    }

    return { message: "Account activated successfully and Welcome Letter sent" };
};

// ✅ STEP 7: Document Uploads
export const uploadEmployeeDocumentsService = async (userId, files) => {
    const employee = await prisma.employee.findUnique({
        where: { userId }
    });

    if (!employee) throw new Error("Employee profile not found. Complete profile first.");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    const documents = [];

    for (const [fieldname, fileArray] of Object.entries(files)) {
        const file = fileArray[0];
        const docType = fieldname.toUpperCase(); // e.g., PAN, AADHAAR

        const doc = await prisma.employeeDocument.create({
            data: {
                employeeId: employee.id,
                name: docType,
                fileUrl: `/uploads/employee-docs/${file.filename}`,
                status: "PENDING"
            }
        });
        documents.push(doc);
    }
    
    // Also store profile photo locally if uploaded
    if (files.profilePhoto) {
        await prisma.employee.update({
            where: { id: employee.id },
            data: { profilePhoto: `/uploads/employee-docs/${files.profilePhoto[0].filename}` }
        });
    }
    


    return { message: "Documents uploaded successfully", documents };
};

// ✅ STEP 8: Bank Details
export const saveBankDetailsService = async (userId, data) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    if (data.accountNumber !== data.confirmAccountNumber) {
        throw Error("Account numbers do not match");
    }

    await prisma.employeeBank.upsert({
        where: { employeeId: employee.id },
        update: {
            bankName: data.bankName,
            accountHolderName: data.accountHolderName,
            accountNumber: data.accountNumber,
            ifscCode: data.ifscCode,
            branchName: data.branchName,
            upiId: data.upiId
        },
        create: {
            employeeId: employee.id,
            bankName: data.bankName,
            accountHolderName: data.accountHolderName,
            accountNumber: data.accountNumber,
            ifscCode: data.ifscCode,
            branchName: data.branchName,
            upiId: data.upiId
        }
    });



    return { message: "Bank details saved" };
};

// ✅ STEP 9: Nominee Details
export const saveNomineeService = async (userId, data) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    await prisma.employeeNominee.upsert({
        where: { employeeId: employee.id },
        update: {
            nomineeName: data.nomineeName,
            relationship: data.relationship,
            dob: data.dob ? new Date(data.dob) : null,
            gender: data.gender,
            phone: data.phone,
            email: data.email,
            aadhaarNumber: data.aadhaarNumber,
            panNumber: data.panNumber,
            nomineePercentage: data.nomineePercentage,
            address: data.address
        },
        create: {
            employeeId: employee.id,
            nomineeName: data.nomineeName,
            relationship: data.relationship,
            dob: data.dob ? new Date(data.dob) : null,
            gender: data.gender,
            phone: data.phone,
            email: data.email,
            aadhaarNumber: data.aadhaarNumber,
            panNumber: data.panNumber,
            nomineePercentage: data.nomineePercentage,
            address: data.address
        }
    });



    return { message: "Nominee details saved" };
};

// ✅ STEP 10: Compliance & Finalize
export const saveComplianceAndFinalizeService = async (userId, data) => {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    if (!employee) throw Error("Employee profile not found");
    if (employee.onboardingCompleted) throw Error("Onboarding has already been completed. You cannot submit onboarding again.");

    // Validate UAN number format if provided
    if (data.uanNumber) {
        const uanRegex = /^1\d{11}$/;
        if (!uanRegex.test(data.uanNumber)) {
            throw new Error("Invalid UAN number format. It must be exactly 12 digits starting with '1'.");
        }
    }

    await prisma.employeeCompliance.upsert({
        where: { employeeId: employee.id },
        update: {
            uanNumber: data.uanNumber || null,
            pfNumber: data.pfNumber || null,
            esiNumber: data.esiNumber || null
        },
        create: {
            employeeId: employee.id,
            uanNumber: data.uanNumber || null,
            pfNumber: data.pfNumber || null,
            esiNumber: data.esiNumber || null
        }
    });


    // Finalize onboarding
    await prisma.employee.update({
        where: { id: employee.id },
        data: { 
            onboardingCompleted: true,
            status: "PENDING_APPROVAL" // Moves to HR verification
        }
    });

    return { 
        message: "Onboarding completed successfully! Your profile is now under review by HR.",
        onboardingCompleted: true 
    };
};

// ✅ STEP 5: HR Document Verification (BGV - Part 1)
export const updateDocumentStatusService = async ({ documentId, status, remarks }) => {
    const doc = await prisma.employeeDocument.update({
        where: { id: documentId },
        data: { status, remarks }
    });
    return { message: `Document marked as ${status}`, doc };
};

// ✅ STEP 5: Final BGV Approval/Rejection (BGV - Part 2)
export const finalBGVApprovalService = async ({ employeeId, status, remarks }) => {
    const employee = await prisma.employee.update({
        where: { id: employeeId },
        data: { 
            bgvStatus: status, 
            bgvRemarks: remarks,
            // If rejected, keep status as PENDING_APPROVAL or move to SUSPENDED
            status: status === "REJECTED" ? "SUSPENDED" : "PENDING_APPROVAL"
        },
        include: {
             user: true }
    });

    if (status === "REJECTED") {
        await sendEmail(
            employee.user.email,
            "Onboarding Update - BGV Verification",
            `<h3>Background Verification Update</h3>
             <p>Dear ${employee.user.name},</p>
             <p>We regret to inform you that your background verification was not successful.</p>
             <p><strong>Remarks:</strong> ${remarks}</p>`
        );
    }

    return { message: `Employee BGV marked as ${status}`, employee };
};

// ✅ STEP 6: Assign Salary + Manager
export const assignTermsService = async ({ employeeId, salaryDetails, managerId }) => {
    const { basic, hra, allowances, bonus, deductions } = salaryDetails;

    const [salary, employee] = await prisma.$transaction([
        prisma.salaryStructure.upsert({
            where: { employeeId },
            create: { employeeId, basic, hra, allowances, bonus, deductions },
            update: { basic, hra, allowances, bonus, deductions }
        }),
        prisma.employee.update({
            where: { id: employeeId },
            data: { managerId }
        })
    ]);

    return { message: "Employment terms assigned successfully", salary, employee };
};

// ✅ CONSOLIDATED HR STEP: Finalize Joining (Industry Standard)
export const finalizeEmployeeJoiningService = async ({ 
    employeeId, 
    managerId, 
    salaryBreakdown,
    salary,          // Accept plain gross salary number from HR
    bgvStatus,
    bgvRemarks,
    probationPeriod,
    noticePeriod
}) => {
    const employee = await prisma.employee.findUnique({
        where: { id: employeeId },
        include: { 
            user: true,
            company: true,
            designation: true,
            experiences: true,
            compliance: true
        }
    });


    if (!employee) throw Error("Employee not found");

    // 🚀 SMART LOGIC: Auto-calculate Notice Period if not provided
    let finalNoticePeriod = noticePeriod;
    if (!finalNoticePeriod) {
        const level = employee.designation?.level || 1;
        // Primary fallback: Industry standard based on level
        // Secondary fallback: Company default setting
        finalNoticePeriod = level >= 3 ? "90 Days" : (employee.company.defaultNoticePeriod || "30 Days");
    }

    const result = await prisma.$transaction(async (tx) => {
        // 1. Update BGV Status, Manager, and Contract Terms
        await tx.employee.update({
            where: { id: employeeId },
            data: { 
                bgvStatus: bgvStatus || "APPROVED",
                bgvRemarks,
                managerId,
                probationPeriod: probationPeriod || employee.company.defaultProbationPeriod || "6 Months",
                noticePeriod: finalNoticePeriod,
                status: bgvStatus === "REJECTED" ? "SUSPENDED" : "ACTIVE"
            }
        });

        // 2. Map Salary Structure (Industry Standard Calculation with Dynamic PF Rules)
        const companyCompliance = await tx.companyCompliance.findUnique({
            where: { companyId: employee.companyId }
        });
        const pfEnabled = companyCompliance?.pfEnabled || false;

        const hasPreviousPf = !!(employee.compliance?.uanNumber || employee.compliance?.pfNumber);
        const isExperiencedWithPf = (employee.experiences.length > 0) && hasPreviousPf;
        const pfActive = pfEnabled && isExperiencedWithPf;

        // Priority: salaryBreakdown object > plain salary number > offer letter auto-calc
        let finalSalary = salaryBreakdown;

        // If HR sent a plain gross salary number, build a standard breakdown
        if (!finalSalary && salary) {
            const gross = Number(salary);
            const basic = gross * 0.5;
            const hra = gross * 0.2;
            const allowances = gross * 0.3;
            
            const pfEmployeeVal = pfActive ? (basic * 0.12) : 0;
            const pfEmployerVal = pfActive ? (basic * 0.12) : 0;
            const esiEmployeeVal = gross < 21000 ? (gross * 0.0075) : 0;
            const esiEmployerVal = gross < 21000 ? (gross * 0.0325) : 0;
            
            const deductions = pfEmployeeVal + esiEmployeeVal;
            const netSalary = gross - deductions;

            finalSalary = {
                basic, hra, allowances,
                bonus: 0,
                pfEmployee: pfEmployeeVal,
                esiEmployee: esiEmployeeVal,
                pfEmployer: pfEmployerVal,
                esiEmployer: esiEmployerVal,
                deductions,
                netSalary
            };
        }

        if (!finalSalary) {
            const offer = await tx.offerLetter.findFirst({
                where: { employeeEmail: employee.user.email },
                orderBy: { createdAt: "desc" }
            });

            if (offer) {
                // Fetch Company Industry Template
                const company = await tx.company.findUnique({
                    where: { id: employee.companyId },
                    include: { industryType: { include: { salaryTemplate: true } } }
                });

                const template = company.industryType?.salaryTemplate;
                const gross = offer.ctc;

                if (template) {
                    // ✅ ADVANCED INDUSTRY CALCULATION
                    const basic = gross * (template.basicPercentage / 100);
                    const hra = basic * (template.hraPercentageOfBasic / 100);
                    const allowances = gross - (basic + hra); // Balance goes to allowances

                    // Statutory Components
                    const pfEmployee = pfActive ? (basic * (template.pfPercentage / 100)) : 0;
                    const esiEmployee = gross < 21000 ? gross * (template.esiPercentage / 100) : 0;
                    
                    const pfEmployer = pfActive ? (basic * (template.employerPfPercentage / 100)) : 0;
                    const esiEmployer = gross < 21000 ? gross * (template.employerEsiPercentage / 100) : 0;

                    const deductions = pfEmployee + esiEmployee;
                    const netSalary = gross - deductions;

                    finalSalary = {
                        basic,
                        hra,
                        allowances,
                        bonus: 0,
                        pfEmployee,
                        esiEmployee,
                        pfEmployer,
                        esiEmployer,
                        deductions,
                        netSalary
                    };
                } else {
                    // Fallback to basic 50/40/10 if no template found
                    finalSalary = {
                        basic: gross * 0.5,
                        hra: gross * 0.4,
                        allowances: gross * 0.1,
                        bonus: 0,
                        deductions: 0,
                        netSalary: gross
                    };
                }
            }
        }

        if (finalSalary) {
            // Apply PF compliance filter to direct salary breakdowns if passed
            if (!pfActive) {
                const pfDeduction = finalSalary.pfEmployee || 0;
                finalSalary.pfEmployee = 0;
                finalSalary.pfEmployer = 0;
                finalSalary.deductions = Math.max(0, (finalSalary.deductions || 0) - pfDeduction);
                finalSalary.netSalary = (finalSalary.netSalary || 0) + pfDeduction;
            }

            await tx.salaryStructure.upsert({
                where: { employeeId },
                create: { 
                    employee: { connect: { id: employeeId } }, 
                    basic: finalSalary.basic, 
                    hra: finalSalary.hra, 
                    allowances: finalSalary.allowances, 
                    bonus: finalSalary.bonus || 0, 
                    pfEmployee: finalSalary.pfEmployee || 0,
                    esiEmployee: finalSalary.esiEmployee || 0,
                    pfEmployer: finalSalary.pfEmployer || 0,
                    esiEmployer: finalSalary.esiEmployer || 0,
                    deductions: finalSalary.deductions || 0,
                    netSalary: finalSalary.netSalary || finalSalary.basic + finalSalary.hra + finalSalary.allowances
                },
                update: { 
                    basic: finalSalary.basic, 
                    hra: finalSalary.hra, 
                    allowances: finalSalary.allowances, 
                    bonus: finalSalary.bonus || 0,
                    pfEmployee: finalSalary.pfEmployee || 0,
                    esiEmployee: finalSalary.esiEmployee || 0,
                    pfEmployer: finalSalary.pfEmployer || 0,
                    esiEmployer: finalSalary.esiEmployer || 0,
                    deductions: finalSalary.deductions || 0,
                    netSalary: finalSalary.netSalary || finalSalary.basic + finalSalary.hra + finalSalary.allowances
                }
            });
        }

        // 3. Activate the User Account
        if (bgvStatus !== "REJECTED") {
            await tx.user.update({
                where: { id: employee.userId },
                data: { status: "ACTIVE" }
            });
        }

        return { bgvStatus };
    });

    // 4. Send Appointment Letter and Welcome Email (Background)
    if (bgvStatus === "APPROVED") {
        const desig = await prisma.designation.findUnique({ where: { id: employee.designationId } });
        const position = desig?.title || "Team Member";

        const { generateJoiningLetter } = await import("../utils/pdfGenerator.js");

        generateJoiningLetter({
            email: employee.user.email,
            name: employee.user.name,
            position: position,
            joiningDate: new Date().toLocaleDateString(),
            company: {
                name: employee.company.name,
                logo: employee.company.companyLogo
            }
        }).then(({ filePath, fileName }) => {
            sendEmail(
                employee.user.email,
                "Welcome Aboard! Appointment Letter - GOExperts HRMS",
                `<h3>Welcome to the Team, ${employee.user.name}!</h3>
                 <p>Congratulations! Your onboarding is complete and your account is now <strong>ACTIVE</strong>.</p>
                 <p>Please find your formal <strong>Appointment Letter</strong> attached.</p>
                 <br/>
                 <a href="${process.env.FRONTEND_URL}/login" 
                    style="background: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
                    Login to Dashboard
                 </a>`,
                [{ filename: fileName, path: filePath }]
            ).catch(err => console.error("Welcome Email Failed:", err.message));
        }).catch(err => console.error("Joining PDF Generation Failed:", err.message));
    }

    return { 
        success: true, 
        message: bgvStatus === "APPROVED" 
            ? "Employee finalized, salary mapped, and activation email sent!" 
            : "Employee rejected and account suspended." 
    };
};

// ✅ HR STEP: Get all onboarding details for review
export const getEmployeeOnboardingDetailsService = async (employeeId) => {
    const employee = await prisma.employee.findUnique({
        where: { id: employeeId },
        include: {
            user: { select: { name: true, email: true, status: true } },
            department: true,
            designation: true,
            personal: true,
            emergencyContacts: true,
            educations: true,
            experiences: true,
            skills: true,
            documents: true,
            bankDetails: true,
            nominee: true,
            compliance: true
        }
    });

    if (!employee) throw Error("Employee not found");

    return employee;
};

// HR STEP: Get all employee onboarding reviews for a company
export const getAllEmployeeReviewsService = async (companyId) => {
    if (!companyId) throw Error("Company id is required");

    const employees = await prisma.employee.findMany({
        where: { companyId },
        select: {
            id: true,
            employeeCode: true,
            status: true,
            bgvStatus: true,
            onboardingCompleted: true,
            joiningDate: true,
            employmentType: true,
            profilePhoto: true,
            user: { select: { name: true, email: true } },
            department: { select: { name: true } },
            designation: { select: { title: true } },
            documents: { select: { status: true } }
        },
        orderBy: { joiningDate: "desc" }
    });

    // 🏆 Industry Level Polish: Return only a slim summary for the list view
    return employees.map(emp => {
        const totalDocs = emp.documents.length;
        const approvedDocs = emp.documents.filter(d => d.status === "APPROVED").length;
        const documentProgress = totalDocs > 0 ? Math.round((approvedDocs / totalDocs) * 100) : 0;

        return {
            id: emp.id,
            employeeCode: emp.employeeCode,
            name: emp.user?.name || "Unknown",
            email: emp.user?.email || "N/A",
            avatar: emp.profilePhoto || null,
            department: emp.department?.name || "Not Assigned",
            designation: emp.designation?.title || "Not Assigned",
            employmentType: emp.employmentType,
            joiningDate: emp.joiningDate,
            status: emp.status,
            bgvStatus: emp.bgvStatus,
            onboardingCompleted: emp.onboardingCompleted,
            documentProgress: `${documentProgress}%`,
            pendingAction: emp.status === "PENDING_APPROVAL"
        };
    });
};


// ✅ HR STEP: Get Salary Preview (Auto-Calculation for UI)
export const getSalaryPreviewService = async (employeeId) => {
    const employee = await prisma.employee.findUnique({
        where: { id: employeeId },
        include: { company: true, user: true }
    });

    if (!employee) throw Error("Employee not found");

    const offer = await prisma.offerLetter.findFirst({
        where: { employeeEmail: employee.user.email },
        orderBy: { createdAt: "desc" }
    });

    if (!offer) throw Error("No offer letter found for this employee to calculate salary.");

    const company = await prisma.company.findUnique({
        where: { id: employee.companyId },
        include: { industryType: { include: { salaryTemplate: true } } }
    });

    const template = company.industryType?.salaryTemplate;
    const gross = offer.salary;

    if (!template) {
        // Fallback if no template exists
        return {
            gross,
            basic: gross * 0.5,
            hra: gross * 0.2, // 40% of 50%
            allowances: gross * 0.3,
            pfEmployee: 0,
            esiEmployee: 0,
            netSalary: gross,
            isStandard: false
        };
    }

    const basic = gross * (template.basicPercentage / 100);
    const hra = basic * (template.hraPercentageOfBasic / 100);
    const allowances = gross - (basic + hra);

    const pfEmployee = basic * (template.pfPercentage / 100);
    const esiEmployee = gross < 21000 ? gross * (template.esiPercentage / 100) : 0;
    const deductions = pfEmployee + esiEmployee;
    
    const pfEmployer = basic * (template.employerPfPercentage / 100);
    const esiEmployer = gross < 21000 ? gross * (template.employerEsiPercentage / 100) : 0;

    return {
        gross,
        basic,
        hra,
        allowances,
        pfEmployee,
        esiEmployee,
        pfEmployer,
        esiEmployer,
        deductions,
        netSalary: gross - deductions,
        templateName: template.name,
        isStandard: true
    };
};

/**
 * ✅ UNIFIED ONBOARDING: ONE API FOR EVERYTHING
 * Accepts all fields and files in a single massive payload.
 */
export const finalizeFullOnboardingService = async (userId, data, files = {}) => {
    const employee = await prisma.employee.findUnique({ 
        where: { userId },
        include: { user: true, company: true }
    });
    if (!employee) throw Error("Employee profile not found");

    // 🚫 GUARD: Prevent duplicate onboarding submissions
    if (employee.onboardingCompleted) {
        throw Error("Onboarding has already been completed. You cannot submit onboarding again.");
    }

    // 🏆 Industry Level Polish: Smart Validation
    // 1. Legal Declaration Check
    if (!data.isDeclaredTrue) {
        throw Error("You must accept the legal declaration to complete onboarding.");
    }

    if (files.experienceLetter && !files.relieving_letter) {
        files.relieving_letter = files.experienceLetter;
        delete files.experienceLetter;
    }

    const validExperience = Array.isArray(data.experience)
        ? data.experience
            .filter(exp => exp && (
                exp.companyName ||
                exp.designation ||
                exp.role ||
                exp.startDate ||
                exp.endDate ||
                exp.responsibilities ||
                (Array.isArray(exp.technologies) && exp.technologies.length > 0)
            ))
            .map(exp => ({
                ...exp,
                companyName: exp.companyName?.trim(),
                role: (exp.designation || exp.role)?.trim(),
                responsibilities: exp.responsibilities?.trim()
            }))
        : [];

    // 2. Mandatory Documents Check for All Employees
    if (!files.aadhaar) {
        throw Error("Aadhaar card upload is mandatory.");
    }
    if (!files.pan) {
        throw Error("PAN card upload is mandatory.");
    }
    // if (!files.bankPassbook) {
    //     throw Error("Bank Passbook or Statement upload is mandatory.");
    // }
    if (!files.education_proof) {
        throw Error("Education proof upload is mandatory.");
    }
    if (!files.signature) {
        throw Error("Signature upload is mandatory.");
    }
    if (!files.profilePhoto) {
        throw Error("Profile photo upload is mandatory.");
    }

    // 3. Experienced Professional Check
    const hasExperience = data.isExperienced || employee.employmentType === "EXPERIENCED";
    if (hasExperience) {
        if (validExperience.length === 0) {
            throw Error("Previous work experience is mandatory for experienced professionals.");
        }
        for (const exp of validExperience) {
            if (!exp.companyName || !exp.role || !exp.startDate || Number.isNaN(new Date(exp.startDate).getTime())) {
                throw Error("Company name, role, and valid start date are mandatory for each previous experience.");
            }
            if (exp.endDate && Number.isNaN(new Date(exp.endDate).getTime())) {
                throw Error("Valid end date is required when an experience end date is provided.");
            }
            if (exp.endDate && new Date(exp.endDate) < new Date(exp.startDate)) {
                throw Error("Experience end date cannot be earlier than start date.");
            }
        }
        if (!files.relieving_letter) {
            throw Error("Relieving letter from the previous employer is mandatory.");
        }
        if (!files.payslips) {
            throw Error("Recent payslips are mandatory for salary verification.");
        }
    }
    data.experience = validExperience;

    const result = await prisma.$transaction(async (tx) => {
        // 1. Personal & Identity
        if (data.personal) {
            await tx.employeePersonal.upsert({
                where: { employeeId: employee.id },
                update: {
                    gender: data.personal.gender,
                    dob: data.personal.dob ? new Date(data.personal.dob) : undefined,
                    maritalStatus: data.personal.maritalStatus,
                    bloodGroup: data.personal.bloodGroup,
                    nationality: data.personal.nationality,
                    personalEmail: data.contact?.personalEmail,
                    phone: data.contact?.phone,
                    alternatePhone: data.contact?.alternatePhone,
                    address: data.contact?.address,
                    city: data.contact?.city,
                    state: data.contact?.state,
                    country: data.contact?.country,
                    pincode: data.contact?.pincode
                },
                create: {
                    employeeId: employee.id,
                    gender: data.personal.gender,
                    dob: data.personal.dob ? new Date(data.personal.dob) : null,
                    maritalStatus: data.personal.maritalStatus,
                    bloodGroup: data.personal.bloodGroup,
                    nationality: data.personal.nationality,
                    personalEmail: data.contact?.personalEmail,
                    phone: data.contact?.phone,
                    alternatePhone: data.contact?.alternatePhone,
                    address: data.contact?.address,
                    city: data.contact?.city,
                    state: data.contact?.state,
                    country: data.contact?.country,
                    pincode: data.contact?.pincode
                }
            });
        }

        // 2. Emergency Contacts
        if (data.emergency && Array.isArray(data.emergency)) {
            await tx.employeeEmergencyContact.deleteMany({ where: { employeeId: employee.id } });
            await tx.employeeEmergencyContact.createMany({
                data: data.emergency.map(ec => ({
                    employeeId: employee.id,
                    contactPersonName: ec.contactPersonName,
                    relationship: ec.relationship,
                    contactNumber: ec.contactNumber
                }))
            });
        }

        // 3. Education
        if (data.education && Array.isArray(data.education)) {
            await tx.employeeEducation.deleteMany({ where: { employeeId: employee.id } });
            await tx.employeeEducation.createMany({
                data: data.education.map(edu => ({
                    employeeId: employee.id,
                    degree: edu.degree,
                    specialization: edu.specialization,
                    college: edu.college,
                    university: edu.university,
                    percentage: edu.percentage,
                    startYear: edu.startYear,
                    endYear: edu.endYear
                }))
            });
        }

        // 4. Experience
        if (hasExperience) {
            await tx.employeeExperience.deleteMany({ where: { employeeId: employee.id } });
            await tx.employeeExperience.createMany({
                data: data.experience.map(exp => ({
                    employeeId: employee.id,
                    companyName: exp.companyName,
                    role: exp.role,
                    startDate: new Date(exp.startDate),
                    endDate: exp.endDate ? new Date(exp.endDate) : null,
                    technologies: exp.technologies,
                    responsibilities: exp.responsibilities
                }))
            });
        } else {
            await tx.employeeExperience.deleteMany({ where: { employeeId: employee.id } });
        }

        // 5. Skills
        if (data.skills) {
            await tx.employeeSkill.deleteMany({ where: { employeeId: employee.id } });
            await tx.employeeSkill.create({
                data: {
                    employeeId: employee.id,
                    primarySkills: Array.isArray(data.skills.primarySkills) ? data.skills.primarySkills : [],
                    secondarySkills: Array.isArray(data.skills.secondarySkills) ? data.skills.secondarySkills : [],
                    certifications: Array.isArray(data.skills.certifications) ? data.skills.certifications : [],
                    languagesKnown: Array.isArray(data.skills.languagesKnown) ? data.skills.languagesKnown : [],
                    linkedinUrl: data.skills.linkedinUrl || null,
                    githubUrl: data.skills.githubUrl || null,
                    portfolioUrl: data.skills.portfolioUrl || null
                }
            });
        }

        // 6. Bank Details
        if (data.bank) {
            await tx.employeeBank.upsert({
                where: { employeeId: employee.id },
                update: {
                    bankName: data.bank.bankName,
                    accountHolderName: data.bank.accountHolderName,
                    accountNumber: data.bank.accountNumber,
                    ifscCode: data.bank.ifscCode,
                    branchName: data.bank.branchName,
                    upiId: data.bank.upiId
                },
                create: {
                    employeeId: employee.id,
                    bankName: data.bank.bankName,
                    accountHolderName: data.bank.accountHolderName,
                    accountNumber: data.bank.accountNumber,
                    ifscCode: data.bank.ifscCode,
                    branchName: data.bank.branchName,
                    upiId: data.bank.upiId
                }
            });
        }

        // 7. Nominee Details
        if (data.nominee) {
            await tx.employeeNominee.upsert({
                where: { employeeId: employee.id },
                update: {
                    nomineeName: data.nominee.nomineeName,
                    relationship: data.nominee.relationship,
                    dob: data.nominee.dob ? new Date(data.nominee.dob) : undefined,
                    gender: data.nominee.gender,
                    phone: data.nominee.phone,
                    email: data.nominee.email,
                    aadhaarNumber: data.nominee.aadhaarNumber,
                    panNumber: data.nominee.panNumber,
                    nomineePercentage: data.nominee.nomineePercentage,
                    address: data.nominee.address
                },
                create: {
                    employeeId: employee.id,
                    nomineeName: data.nominee.nomineeName,
                    relationship: data.nominee.relationship,
                    dob: data.nominee.dob ? new Date(data.nominee.dob) : null,
                    gender: data.nominee.gender,
                    phone: data.nominee.phone,
                    email: data.nominee.email,
                    aadhaarNumber: data.nominee.aadhaarNumber,
                    panNumber: data.nominee.panNumber,
                    nomineePercentage: data.nominee.nomineePercentage,
                    address: data.nominee.address
                }
            });
        }

        // 8. Compliance
        if (data.compliance) {
            await tx.employeeCompliance.upsert({
                where: { employeeId: employee.id },
                update: {
                    uanNumber: data.compliance.uanNumber,
                    pfNumber: data.compliance.pfNumber,
                    esiNumber: data.compliance.esiNumber
                },
                create: {
                    employeeId: employee.id,
                    uanNumber: data.compliance.uanNumber,
                    pfNumber: data.compliance.pfNumber,
                    esiNumber: data.compliance.esiNumber
                }
            });
        }

        // 9. Process File Uploads (if any)
        if (files && Object.keys(files).length > 0) {
            for (const [fieldname, fileArray] of Object.entries(files)) {
                const file = fileArray[0];
                const docType = fieldname.toUpperCase();
                
                // 💡 SMART LOGIC: Use file.path for Cloudinary URLs, fallback to filename for local
                const fileUrl = file.path || `/uploads/employee-docs/${file.filename}`;

                if (fieldname === "profilePhoto") {
                    await tx.employee.update({
                        where: { id: employee.id },
                        data: { 
                            profilePhoto: fileUrl,
                            faceVerificationPhoto: fileUrl
                        }
                    });
                    // Also sync to User record
                    await tx.user.update({
                        where: { id: employee.userId },
                        data: { profileLogo: fileUrl }
                    });
                } else if (fieldname === "signature") {
                    await tx.employee.update({
                        where: { id: employee.id },
                        data: { signature: fileUrl }
                    });
                } else {
                    await tx.employeeDocument.create({
                        data: {
                            employeeId: employee.id,
                            name: docType,
                            fileUrl: fileUrl,
                            status: "PENDING"
                        }
                    });
                }
            }
        }

        // 10. Finalize Employee State
        return await tx.employee.update({
            where: { id: employee.id },
            data: { 
                firstName: data.personal?.firstName || undefined,
                middleName: data.personal?.middleName || undefined,
                lastName: data.personal?.lastName || undefined,
                employmentType: hasExperience ? "EXPERIENCED" : "FRESHER",
                onboardingCompleted: true,
                isDeclaredTrue: true,
                status: "PENDING_APPROVAL"
            }
        });
    }, { timeout: 30000 });

    // 🏆 Industry Level Polish: Automated Email Notifications
    // 1. Send confirmation to Employee
    sendEmail(
        employee.user.email,
        "Onboarding Received - Pending Verification",
        `<h3>Onboarding Submission Successful</h3>
         <p>Dear ${employee.user.name},</p>
         <p>Your profile has been submitted successfully! Our HR team is now verifying your documents.</p>
         <p>This process usually takes 24-48 hours. We will notify you once the verification is complete.</p>`
    ).catch(err => console.error("Employee Submission Email Failed:", err.message));

    // 2. Send notification to HR/Owner
    if (employee.company.email) {
        sendEmail(
            employee.company.email,
            "Action Required: New Onboarding Submission",
            `<h3>New Employee Onboarding Submission</h3>
             <p>A new employee, <strong>${employee.user.name}</strong>, has submitted their profile for review.</p>
             <p>Please log in to your dashboard to review their documents and finalize the joining.</p>
             <br/>
             <a href="${process.env.FRONTEND_URL}/login" style="background: #10B981; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                Review Submission
             </a>`
        ).catch(err => console.error("HR Notification Email Failed:", err.message));
    }

    return { 
        success: true,
        message: "Onboarding finalized successfully! Your profile is now under review by HR.",
        employeeId: result.id,
        onboardingCompleted: true 
    };
};