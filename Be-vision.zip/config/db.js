//using prisma tool
import prismaPkg from "@prisma/client";

const { PrismaClient } = prismaPkg;

const prisma = new PrismaClient();

export default prisma;
